You will need the dataset in order to run the code. I provided the dataset in the
zip file because the one downloaded from kaggle had some missing values which casued the
code to break.

The code outputs a confusion matrix of how the network did.  
