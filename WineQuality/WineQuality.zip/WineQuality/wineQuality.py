# wine_quality.py
# Quality ranges from 3 to 9
# import libraries
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import Normalizer
from sklearn.metrics import confusion_matrix
import keras
import matplotlib.patches as mpatches
from keras.models import Sequential
from keras.layers import Dense
import matplotlib.pyplot as plt

# fix seed
np.random.seed(3000)
# Load Dataset
full_dataframe = pd.read_csv("winequalityN2.csv", header = None)
full_dataset = full_dataframe.values

red_train = pd.read_csv("redTrain(CSV).csv", header = None)
red_train_set = red_train.values
red_test = pd.read_csv("redTest(CSV).csv", header = None)
red_test_set = red_test.values

white_train = pd.read_csv("whiteTrain(CSV).csv", header = None)
white_train_set = white_train.values
white_test = pd.read_csv("whiteTest(CSV).csv", header = None)
white_test_set = white_test.values

# Declare/Seperate Data
full_type = full_dataset[1:,0]
full_quality = full_dataset[1:,12].astype('int')
# print(np.unique(full_quality))
full_X = full_dataset[1:,1:12].astype('float32')
# encoder = LabelBinarizer()
# T = encoder.fit_transform(full_quality)

red_train_quality = red_train_set[1:,12]
red_test_quality = red_test_set[1:,12]
red_train_X = red_train_set[1:,1:12].astype('float32')
red_test_X = red_test_set[1:,1:12].astype('float32')


white_train_quality = white_train_set[1:,12]
white_test_quality = white_test_set[1:,12]
white_train_X = white_train_set[1:,1:12].astype('float32')
white_test_X = white_test_set[1:,1:12].astype('float32')

transformer = Normalizer().fit(full_X)
normalized_full_X = transformer.transform(full_X)

full_quality -= 3

full_quality1 = tf.keras.utils.to_categorical(full_quality,7)

batch_size = 100
epochs = 0
learning_rate = 0.001

model = Sequential()
model.add(Dense(units=100, activation='relu',input_dim=11))
model.add(Dense(units=100, activation='relu'))
model.add(Dense(units=7, activation='softmax'))
model.summary()

sgd= keras.optimizers.SGD(lr=learning_rate)
model.compile(loss='mean_squared_error', optimizer = sgd,metrics=['accuracy'])

# Train NN
model.fit(
    full_X, full_quality1,
    batch_size = batch_size,
    epochs = epochs,
    verbose = 2

)

pred = model.predict(full_X)
# print (pred)
score = model.evaluate(full_X, full_quality1, verbose = 0)

# score = model.evaluate(full_X, T, verbose = 0)
# print(score)
print("Test loss: ", score[0])
print("Test accuracy: ", score[1])
test = pred.argmax(1)+1
print(pred)
print(pred.shape)
print(test)
print(full_quality)

cm = confusion_matrix(full_quality, test)
print(cm)
